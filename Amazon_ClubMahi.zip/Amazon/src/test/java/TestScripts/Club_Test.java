package TestScripts;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import PageObjects.Club_Home_Page;
import PageObjects.Club_Review_Page;
import PageObjects.Flipkart_Home_Page;
import PageObjects.Flipkart_Iphone_Xr_Page;
import PageObjects.amazon_Home_Page;
import PageObjects.amazon_IphoneXr_Page;

public class Club_Test {
	@Test
	public void compareAmazonFlipkart()
	{
		System.setProperty("webdriver.chrome.driver","C:\\chandra\\Softwares\\chrome driver 80\\chromedriver_win32\\chromedriver.exe");
	
		WebDriver driver = new ChromeDriver();
		
		Club_Home_Page cm = new Club_Home_Page(driver);
		Club_Review_Page cr = new Club_Review_Page(driver);
		driver.manage().timeouts().pageLoadTimeout(25,TimeUnit.SECONDS);
		WebDriverWait Wait = new WebDriverWait(driver,25);
		driver.get("chrome://settings/clearBrowserData");
		Actions ac = new Actions(driver);
		ac.sendKeys(Keys.ENTER).build().perform();
		
		driver.get("https://www.tripadvisor.in");
		
		Wait.until(ExpectedConditions.titleContains("Tripadvisor Official Site"));
		cm.searchBox.click();
		Wait.until(ExpectedConditions.elementToBeClickable(cm.searchBoxEdit));
		cm.searchBoxEdit.sendKeys("club mahindra");
		Wait.until(ExpectedConditions.elementToBeClickable(cm.searchBoxResult));
		cm.searchBoxResult.click();
		Wait.until(ExpectedConditions.titleContains("CLUB MAHINDRA"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(1000,200)");
		
		ac.moveToElement(cm.writeReview).click().build().perform();
		//cm.writeReview.click();
		 Set<String> windows = driver.getWindowHandles();
		 for( String var: windows)
		 {
			if( driver.switchTo().window(var).getTitle()==" Write a review - Tripadvisor ")
		     break;
		 }
		Wait.until(ExpectedConditions.elementToBeClickable(cr.reviewTitle));
		cr.reviewTitle.sendKeys("Test1");
		cr.reviewTextArea.sendKeys("Beautiful place ,Nice & relaxing rooms and service ( Hospitatlity ) given by Joshi & Chef Shubhankar was very nice.... Do visit..... Thank you Club Mahindra so much..Great going.. keep it up..God Bless");
		
		//cr.ClickCheck1.click();
		js.executeScript("document.getElementsByClassName('ui_bubble_rating fl bubble_00')[0].className='ui_bubble_rating fl bubble_50';");
		
		js.executeScript("document.getElementsByClassName('answersBubbles ui_bubble_rating fl qid12 bubble_00')[0].className='answersBubbles ui_bubble_rating fl qid12 bubble_50';");
		
		js.executeScript("document.getElementsByClassName('answersBubbles ui_bubble_rating fl bubble_00 qid47')[0].className='answersBubbles ui_bubble_rating fl bubble_50 qid47';");
		
		js.executeScript("document.getElementsByClassName('answersBubbles ui_bubble_rating fl qid11 bubble_00')[0].className='answersBubbles ui_bubble_rating fl qid11 bubble_50';");
		
		cr.checkboxaccept.click();
		
		driver.quit();
	}
}
