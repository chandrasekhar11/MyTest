package TestScripts;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Window;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import PageObjects.Flipkart_Home_Page;
import PageObjects.Flipkart_Iphone_Xr_Page;
import PageObjects.amazon_Home_Page;
import PageObjects.amazon_IphoneXr_Page;

public class AmazonTest {
	
	@Test
	public void compareAmazonFlipkart()
	{
		System.setProperty("webdriver.chrome.driver","C:\\chandra\\Softwares\\chrome driver 80\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		amazon_Home_Page am = new amazon_Home_Page(driver);
		amazon_IphoneXr_Page axr = new amazon_IphoneXr_Page(driver);
		driver.get("https://amazon.in");
		driver.manage().timeouts().pageLoadTimeout(25,TimeUnit.SECONDS);
		WebDriverWait Wait = new WebDriverWait(driver,25);
		Wait.until(ExpectedConditions.titleContains("Online Shopping site in India"));
		am.SearchBox.sendKeys("iphone xr 64gb yellow");
		am.Searchicon.click();
		Wait.until(ExpectedConditions.elementToBeClickable(am.iphonexrLink));
		am.iphonexrLink.click();
		 Set<String> windows = driver.getWindowHandles();
		 for( String var: windows)
		 {
			if( driver.switchTo().window(var).getTitle()=="Apple iPhone XR (64GB) - Yellow: Amazon.in: Appario Retail Private Ltd")
		     break;
		 }
		Wait.until(ExpectedConditions.elementToBeClickable(axr.price));
		String amazonprice = axr.price.getText();
		int amazonxrprice = Integer.parseInt(amazonprice.replace("₹ ","").replace(",", "").replace(".00", "").trim());
		System.out.println(amazonxrprice);
		
		Flipkart_Home_Page  fph= new Flipkart_Home_Page(driver);
		Flipkart_Iphone_Xr_Page fxr = new Flipkart_Iphone_Xr_Page(driver);
		driver.get("https://flipkart.com");
		Wait.until(ExpectedConditions.titleContains("Online Shopping"));
		fph.xbutton.click();
		fph.SearchBox.sendKeys("iphone xr 64gb yellow");
		fph.Searchicon.click();
		Wait.until(ExpectedConditions.elementToBeClickable(fph.iphonexrLink));
		fph.iphonexrLink.click();
		 windows = driver.getWindowHandles();
		 for( String var: windows)
		 {
			if( driver.switchTo().window(var).getTitle()=="Apple iPhone XR ( 64 GB Storage, 0 GB RAM ) Online at Best Price On Flipkart.com")
		     break;
		 }
		Wait.until(ExpectedConditions.elementToBeClickable(fxr.price));
		String fpprice = fxr.price.getText();
		int fpxrprice = Integer.parseInt(fpprice.replace("₹","").replace(",", "").trim());
		System.out.println(fpxrprice);
		if(fpxrprice>amazonxrprice)
			System.out.println("amazon is cheaper to buy iphone xr 64 gb");
		else
			System.out.println("flipkar is cheaper to buy iphone xr 64 gb");
		driver.quit();

	}
}
