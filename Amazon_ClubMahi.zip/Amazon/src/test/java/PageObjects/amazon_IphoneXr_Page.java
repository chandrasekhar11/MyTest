package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class amazon_IphoneXr_Page {
	
		
		WebDriver driver;
		PageFactory pf;
		
		public amazon_IphoneXr_Page(WebDriver driver)
		{
			this.driver = driver;
			pf.initElements(driver, this);
		}
		
		@FindBy(xpath = "//td[text()='Deal Price:']/following::span[@id='priceblock_dealprice']")
		public WebElement price;
		
		
}
