package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Flipkart_Home_Page {
	

	WebDriver driver;
	PageFactory pf;
	
	public Flipkart_Home_Page(WebDriver driver)
	{
		this.driver = driver;
		pf.initElements(driver, this);
	}
	
	@FindBy(xpath = "//button[@class='_2AkmmA _29YdH8']")
	public WebElement xbutton;
	
	@FindBy(xpath = "//input[@title='Search for products, brands and more']")
	public WebElement SearchBox;
	
	@FindBy(xpath = "//input[@title='Search for products, brands and more']/following::button")
	public WebElement Searchicon;
	
	@FindBy(xpath = "//div[text()='Apple iPhone XR (Yellow, 64 GB)']")
	public WebElement iphonexrLink;

}
