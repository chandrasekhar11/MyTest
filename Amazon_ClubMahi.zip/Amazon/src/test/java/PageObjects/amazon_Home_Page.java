package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class amazon_Home_Page {
	
	WebDriver driver;
	PageFactory pf;
	public amazon_Home_Page(WebDriver driver)
	{
		this.driver = driver;
		pf.initElements(driver, this);
	}
	
	@FindBy(xpath = "//input[@id='twotabsearchtextbox']")
	public WebElement SearchBox;
	
	@FindBy(xpath = "//input[@class='nav-input' and @type='submit']")
	public WebElement Searchicon;
	
	@FindBy(xpath = "//span[text()='Apple iPhone XR (64GB) - Yellow']")
	public WebElement iphonexrLink;
}
