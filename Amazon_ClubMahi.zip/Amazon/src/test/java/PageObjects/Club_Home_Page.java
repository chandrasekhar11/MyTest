package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Club_Home_Page {
	

	WebDriver driver;
	PageFactory pf;
	
	public Club_Home_Page(WebDriver driver)
	{
		this.driver = driver;
		pf.initElements(driver, this);
	}
	
	@FindBy(xpath = "//div[@title='Search']")
	public WebElement searchBox;

	@FindBy(xpath = "//div[@class='what_with_highlight']/input")
	public WebElement searchBoxEdit;
	
	@FindBy(xpath = "//div[@class='first-row']/span[text()=' Madikeri, Coorg']")
	public WebElement searchBoxResult;
	
	@FindBy(xpath = "//a[text()='Write a review']")
	public WebElement writeReview;
	
}