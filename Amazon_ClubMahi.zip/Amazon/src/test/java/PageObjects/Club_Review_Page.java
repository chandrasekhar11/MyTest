package PageObjects;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;



public class Club_Review_Page {
	

	WebDriver driver;
	PageFactory pf;
	
	public Club_Review_Page(WebDriver driver)
	{
		this.driver = driver;
		pf.initElements(driver, this);
	}
	
	@FindBy(xpath = "//select[@name='qid10']")
	public WebElement selectRating;
	
	@FindBy(xpath = "//div[@id='REVIEW_TITLE']/input")
	public WebElement reviewTitle;
	
	@FindBy(xpath = "//div[@id='REVIEW_TEXT']/textarea")
	public WebElement reviewTextArea;
	
	@FindBy(xpath = "//span[@class='ui_bubble_rating fl bubble_00']")
	public WebElement ClickCheck1;
	
	@FindBy(xpath = "//span[@id='bubble_rating' and  @class='ui_bubble_rating fl bubble_50']")
	public WebElement ratinghotel1;
	
	@FindBy(xpath = "//span[@class='answersBubbles ui_bubble_rating fl qid12 bubble_50']")
	public WebElement ratinghotel2;
	
	@FindBy(xpath = "//span[@class='answersBubbles ui_bubble_rating fl bubble_50 qid13']")
	public WebElement ratinghotel3;
	
	@FindBy(xpath = "//span[@class='answersBubbles ui_bubble_rating fl bubble_50 qid11]")
	public WebElement ratinghotel4;
	
	@FindBy(xpath="//div[@class='willing ']/input[@type='checkbox']")
	public WebElement checkboxaccept;
	
}