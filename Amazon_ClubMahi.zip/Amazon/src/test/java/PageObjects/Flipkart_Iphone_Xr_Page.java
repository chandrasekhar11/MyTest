package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Flipkart_Iphone_Xr_Page {
	WebDriver driver;
	PageFactory pf;
	
	public Flipkart_Iphone_Xr_Page(WebDriver driver)
	{
		this.driver = driver;
		pf.initElements(driver, this);
	}
	
	@FindBy(xpath = "//div[@class='_1vC4OE _3qQ9m1']")
	public WebElement price;
}
